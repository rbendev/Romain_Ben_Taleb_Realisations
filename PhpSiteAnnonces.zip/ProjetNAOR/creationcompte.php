<?php session_start() ?>

<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
    <!--   <link rel="stylesheet" href="css/main.css"> -->
    <!--    <script src="js/main.js"></script> -->
        <title>Projet NAOR : Nelly Alex Omar Romain</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>

  <body>
<?php

    //page qui s'ouvre lorsque l'utilisateur souhaite créer un compte
    require_once(dirname(__FILE__) . '/classes/classeUtilisateur.php');

    $ma_classe_utilisateur = new classeUtilisateur();

    //la page contient un formulaire pour créer les enregistrer les données utilisateurs
    //les données sont vérifiées avant l'envoie du formulaire par du javascript
    //puis la page est rechargée par la méthode postal
    //si la variable $_POST n'est pas vide
    //on détruit la session précédentes
    //on crée une session et on initialise la variable $_SESSION[userid] avec l'userid de l'utilisateur qui vient dêtre créé
    //on affiche la page de consultation de toutes les annonces
    if(count($_POST) > 0){
      session_destroy();
      session_start();
      $_SESSION['user'] = $ma_classe_utilisateur->createUtilisateur($_POST);
      header('Location:/ProjetNAOR/toutesannonces.php');
    }
?>
<div class="sticky-top" style="border-bottom-style: solid; border-color: red;">
	<nav class="navbar navbar-expand-md navbar-dark bg-dark">
	  <a href="index.php"><img src = "img/NAOR.png" class="img-fluid hoverable" alt="Responsive image" width="240" height="560"></a>
	    <div class="container" role="main">
	      <div class="row">
	        <div class="text-center text-white">
	        <h1> Création de votre compte sur le site NAOR </h1>
	        </div>
	      </div>
	</nav>
</div>

  <div>
    </p><br><br></p>
  </div>


  <div class="container" role="main">

    <div class="row mt-5">
      <div class ="col-sm-12">
        <div class="text-center">
        <h2>Création de votre compte</h2>
      </div>
    </div>

    <div class="row mt-5">
      <div class ="col-sm-12">
        <form method="post">
        <fieldset>
            <div class="form-group">
                <label for="nom">Nom</label>
                <input type="text" class="form-control" id="nom" name="nom" placeholder="Nom" size="60" maxlength="60" />
            </div>
            <div class="form-group">
                <label for="prenom">Pénom</label>
                <input type="text" class="form-control" id="prenom" name="prenom" placeholder="Prénom" size="60" maxlength="60" />
            </div>
            <div class="form-group">
                <label for="login">Login / Nom d'utilisateur</label>
                <input type="text" class="form-control" id="login" name="login" placeholder="Votre nom d'utilsateur" size="60" maxlength="60" />
            </div>
            <div class="form-group">
                <label for="mdp">Mot de passe</label>
                <input type="password" class="form-control" id="mdp" name="mdp" placeholder="Mot de passe" size="60" maxlength="60" />
            </div>
            <div class="form-group">
                <label for="code_postal">Code postal</label>
                <input type="text" class="form-control" id="code_postal" name="code_postal" placeholder="Code postal" size="60" maxlength="60"/>
            </div>
            <div class="form-group">
                <label for="ville">Ville</label>
                <input type="text" class="form-control" id="ville" name="ville" placeholder="Ville" size="60" maxlength="60"/>
            </div>
            <div class="form-group">
                <label for="pays">Pays</label>
                <input type="text" class="form-control" id="pays" name="pays" placeholder="Votre pays" size="60" maxlength="60"/>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" id="email" name="email"size="60" maxlength="60"/>
            </div>
            <div class="form-group">
                <label for="telephone">Téléphone</label>
                <input type="text" class="form-control" id="telephone" name="telephone" size="60" maxlength="60"/>
            </div>
            <button type="submit" class="btn btn-primary">Création de votre compte</button>
        </fieldset> 
</form>
      </div>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

  <script>
  (function($){
    function validateEmail(sEmail) {
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        if (filter.test(sEmail)) {
          return true;
        }
        else {
          return false;
        }
    }

    function validateMdp(mdp) {
        var filter = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/;
        if (filter.test(mdp)) {
          return true;
        }
        else {
          return false;
        }
    }

        $('form').submit(function(event){

            var soumettre_form = true;
            var messages_erreurs = [];

            var username = $('input[name=nom]', this).val();
            if(username.length <4 ){
              soumettre_form = false;
              messages_erreurs.push('Nom doit comporter au moins 4 caracteres.');
            }

            var prenom = $('input[name=prenom]', this).val();
            if(prenom.length <4 ){
              soumettre_form = false;
              messages_erreurs.push('Username doit comporter au moins 4 caracteres.');
            }

            var login = $('input[name=login]', this).val();
            if(login.length <8 ){
              soumettre_form = false;
              messages_erreurs.push('Username doit comporter au moins 8 caractères.');
            }

            var mdp = $('input[name=mdp]', this).val();
            if(!validateMdp(mdp)){
              soumettre_form = false;
              messages_erreurs.push("Mot de passe invalide. 8 caracteres (chiffres ou lettres), 1 chiffre, 1 majuscule, 1 minuscule");
            }

            var code_postal = $('input[name=code_postal]', this).val();
            if(code_postal.length != 5){
              soumettre_form = false;
              messages_erreurs.push("CP Invalide, merci de saisir 6 chiffres");
            }

            var ville = $('input[name=ville]', this).val();
            if(ville.length < 2){
              soumettre_form = false;
              messages_erreurs.push("Ville incorrecte, merci de saisir un nom de ville");
            }

            var pays = $('input[name=pays]', this).val();
            if(pays.length < 6){
              soumettre_form = false;
              messages_erreurs.push("CP Invalide, merci de saisir 6 chiffres");
            }

            var email = $('input[name=email]', this).val();
            if(!validateEmail(email)){
              soumettre_form = false;
              messages_erreurs.push("Email invalide");
            }

            var telephone = $('input[name=telephone]', this).val();
            if(telephone.length !=10){
              soumettre_form = false;
              messages_erreurs.push("Telephone invalide, merci de saisir 10 chiffres");
            }

            if(soumettre_form){
              return true;
            }
            else {
              event.preventDefault();
              alert(messages_erreurs.join("\n"));
              return false;
            }
        });

    })(jQuery);

  </script>
</body>
</html>
