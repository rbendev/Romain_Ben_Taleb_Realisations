<?php


require_once(dirname(__FILE__) . '/classes/login.php');


//Si la page est ouverte par la redirection d'un lien déconnextion
//Alors on détruit la précédente session
if(isset($_GET['todo']) && ($_GET['todo']) =="deconnexion" ){
	$_SESSION = [];
	session_destroy();
	header('Location:/ProjetNAOR/index.php');
}

//Lorsque le formulaire Login Mot de passe a été rempli, on identifie l'utilisateur
//ou on l'alerte qu'il n'est pas authentifié
if(count($_POST) > 0) {
	if(isset($_POST['username']) && isset($_POST['mdp'])) {
		$log= new login();
    $userid = $log->connection($_POST['username'], $_POST['mdp']);

    if($userid){
      session_start();
      $_SESSION['user'] = $userid;
      header('Location:/ProjetNAOR/toutesannonces.php');
    }
    else {
        echo "<script>alert(\"Le mot de passe et/ou l'indentifiant sont incorrects.\")</script>";
    }
	}
}

?>


<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
    <!--   <link rel="stylesheet" href="css/main.css"> -->
    <!--    <script src="js/main.js"></script> -->
        <title>Projet NAOR : Nelly Alex Omar Romain</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>
    <body>


<div class="sticky-top" style="border-bottom-style: solid; border-color: red;">
	<nav class="navbar navbar-expand-md navbar-dark bg-dark">
	  <a href="index.php"><img src = "img/NAOR.png" class="img-fluid hoverable" alt="Responsive image" width="240" height="560"></a>
	    <div class="container" role="main">
	      <div class="row">
	        <div class="text-center text-white">
	        <h1> Bienvenue sur le site d'annonces NAOR </h1>
	        </div>
	      </div>
	</nav>
</div>
      <div class="container" role="main">
          <div class="row mt-5">
            <div class="col-3">
            </div>
            <div class="col-6">
                <div class="card">
                  <div class="card-body">
                    <form method="post">
                      <p>
                          <label for="username">Login :     </label>
                          <input name="username" id="username" type="text" size="41" maxlength="40" ?><br />
                      </p>
                      <p>
                          <label for="mdp">Mot de Passe : </label>
                          <input name="mdp" id="mdp" type="password" size="35" maxlength="40" ?><br />
                      </p>
                        <input type="submit" value = "Envoyer"/>
                    </form>
										</br></br>
											<a href="creationcompte.php"><p>Créer un compte</p></a>
                  </div>
                </div>
              </div>
            <div class="col-3">
            </div>
        </div>
    </div>
</body>
</html>
