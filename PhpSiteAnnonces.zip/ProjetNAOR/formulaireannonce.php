<?php session_start() ?>

<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
    <!--   <link rel="stylesheet" href="css/main.css"> -->
    <!--    <script src="js/main.js"></script> -->
        <title>Projet NAOR : Nelly Alex Omar Romain</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>

  <body>
<?php
    require_once(dirname(__FILE__) . '/classes/classeAnnonce.php');
    require_once(dirname(__FILE__) . '/classes/classeUtilisateur.php');

    $ma_classe_annonce = new classeAnnonce();
    $ma_classe_utilisateur = new classeUtilisateur();

      //la page peut être lancée à partir de deux pages sources
      //si la page est lancée depuis une page de consultation d'liste_annonces
      //alors la varianle $_GET contient l'id de l'annonce
      //dans ce cas là on affiche dans cette page le formulaire de Mise à jour de l'annonces
      //il contient donc les informations de l'annonce source par laquelle on est arrivés sur la pages
      //on utilise ma methode updateAnnonce pour mettre à jour cette annonce via le post du formulaire
    	if(isset($_SESSION['user'])) {
    		$utilisateur = $ma_classe_utilisateur->getUtilisateur($_SESSION['user']);
      }
      if(isset($_GET['annonceid'])) {
        $une_annonce = $ma_classe_annonce->getAnnonce($_GET['annonceid']);
      }
      if(count($_POST) > 0 && isset($_POST['annonceid'])){
        $ma_classe_annonce->updateAnnonce($_POST['annonceid'], $_POST, $_SESSION['user']);
      }

      //si l'ouverture de la page provient du bouton "Poster une annonce"
      //on affiche la page de formulaire mais ses champs sont vides
      //on utilise la méthode createAnnonce pour créer une nouvelle annonce sur le post du formulaire
      if(count($_POST) > 0 && $_GET['from']=="poster"){
        $ma_classe_annonce->createAnnonce($_POST, $_SESSION['user']);
      }

?>
<div class="sticky-top" style="border-bottom-style: solid; border-color: red;">
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <a href="index.php"><img src = "img/NAOR.png" class="img-fluid hoverable" alt="Responsive image" width="240" height="560"></a>
      <div class="container" role="main">
        <div class="row">

          <div class="col-3">
            <a href="toutesannonces.php"><button type="button" class="btnBienvenue sur le site d'annonces NAOR btn-info btn-lg btn-block" >Consulter les annonces</button></a>
          </div>

          <div class="col-3">
            <a href="formulaireannonce.php?from=poster"><button type="button" class="btn btn-danger btn-lg btn-block">Poster une annonce</button></a>
          </div>

          <div class="col-3">
            <a href="pageutilisateur.php"><button type="button" class="btn btn-info btn-lg btn-block">Consulter mon Compte</button></a>
          </div>

          <div class="col-3">
            <a href="index.php?todo=deconnexion"><button type="button" class="btn btn-warning btn-lg btn-block h-100">Déconnexion</button></a>
          </div>
      </div>
    </nav>
</div>

  <div>
    </p><br><br></p>
  </div>


  <div class="container" role="main">

    <div class="row mt-5">
      <div class ="col-sm-12">
        <div class="text-center">
        <h2> Vous êtes identifié(e) comme : </h2>
        <?php if(isset($_SESSION['user'])) { echo '<h3>' . $utilisateur['nom'] . ' ' . $utilisateur['prenom'] . '<h3>';}
              else { echo '<h3>' . "Déconnecté(e)" . '<h3>';  };?>
        <?php //on affiche toujours le nom et le prénom de l'utilsiateur authentifié car il sera automatiquement le prorpiétaire de l'annonce ?>
      </div>
    </div>
  </div>

    <div class="row mt-5">
      <div class ="col-sm-12">
        <?php if($_GET['from']=="poster") { ?>
        <?php //Formulaire vide à afficher si on a ouvert la page depuis le bouton poster ?>
        <form method = "post">
            <div >
                  <label for="titre"><h2><bold>Titre de l'annonce :</bold></h2></label><br>
                  <input id="titre" type="text" size="60" maxlength="60" class="form-contol" name="titre" placeholder="Titre de l'annonce"><br><br><br>
            </div>

            <div>
              <label><h2><bold>Catégorie de l'annonce :</bold></h2></label><br>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="categorie" id="categorie1" value="Vente Immobilier">
                <label class="form-check-label" for="categorie1">
                Vente immobilier
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="categorie" id="categorie2" value="Offres Emploi">
                <label class="form-check-label" for="categorie2">
                Offres Emploi
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="categorie" id="categorie3" value="Informatique">
                <label class="form-check-label" for="categorie3">
                  Informatique
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="categorie" id="categorie4" value="Ameublement">
                <label class="form-check-label" for="categorie4">
                  Ameublement
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="categorie" id="categorie5" value="Electroménager">
                <label class="form-check-label" for="categorie5">
                  Electroménager
                </label><br><br><br>
              </div>
            </div>

            <div >
                  <label for="texte"><h2><bold>Description :</bold></h2></label><br>
                  <textarea id="texte" maxlength="500" rows="5" cols="60" name="texte" class="form-contol"> </textarea><br><br><br>
            </div>
            <div >
                  <label for="prix"><h2><bold>Prix :</bold></h2></label><br>
                  <input id="prix" type="text" name="prix" size="30" maxlength="30" class="form-contol" placeholder="Prix"/><br><br><br>
            </div>
            <button type="submit" class="btn btn-primary"><h2><bold>Envoyer votre annonce !</bold></h2></button>
        </form>
      <?php }; ?>


      <?php if($_GET['from']=="annonce") { ?>
        <?php echo $une_annonce['rubrique']; ?>
        <?php //formulaire prérempli si la page a été ouverte à partr de la consultation d'unne annonce ?>
      <form method = "post">
              </label>
          <input type="hidden" name="annonceid" value=<?php echo $une_annonce['annonceid']?> >
          <div >
                <label for="titre"><h2><bold>Titre de l'annonce :</bold></h2></label><br>
                <input id="titre" type="text" size="60" maxlength="60" class="form-contol" name="titre" value="<?php echo $une_annonce['titre']?>"><br><br><br>
          </div>

          <div>
            <label><h2><bold>Catégorie de l'annonce :</bold></h2></label><br>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="categorie" id="categorie" value="Vente Immobilier" <?php if($une_annonce['rubrique'] == "Vente Immobilier") { echo "checked";}; ?>>
              <label class="form-check-label" for="categorie">
              Vente immobilier
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="categorie" id="categorie" value="Offre Emploi"  <?php if($une_annonce['rubrique'] == "Offres Emploi") { echo "checked";}; ?>>
              <label class="form-check-label" for="categorie">
              Offres Emploi
              </label>
            </div>
            <div class="form-check disabled">
              <input class="form-check-input" type="radio" name="categorie" id="categorie" value="Informatique"  <?php if($une_annonce['rubrique'] == "Informatique") { echo "checked";}; ?>>
              <label class="form-check-label" for="categorie">
                Informatique
              </label>
            </div>
            <div class="form-check disabled">
              <input class="form-check-input" type="radio" name="categorie" id="categorie" value="Ameublement"  <?php if($une_annonce['rubrique'] == "Ameublement") { echo "checked";}; ?>>
              <label class="form-check-label" for="categorie">
                Ameublement
              </label>
            </div>
            <div class="form-check disabled">
              <input class="form-check-input" type="radio" name="categorie" id="categorie" value="Electroménager"  <?php if($une_annonce['rubrique'] == "Electroménager") { echo "checked";}; ?>>
              <label class="form-check-label" for="categorie">
                Electroménager
              </label><br><br><br>
            </div>
          </div>

          <div >
                <label for="texte"><h2><bold>Description :</bold></h2></label><br>
                <textarea id="texte" maxlength="500" rows="5" cols="60" name="texte" class="form-contol"><?php echo $une_annonce['texte']?></textarea><br><br><br>
          </div>
          <div >
                <label for="prix"><h2><bold>Prix :</bold></h2></label><br>
                <input id="prix" type="text" name="prix" size="30" maxlength="30" class="form-contol" value=<?php echo $une_annonce['prix']?>><br><br><br>
          </div>
          <button type="submit" class="btn btn-primary"><h2><bold>Envoyer votre annonce !</bold></h2></button><br><br><br>
      </form>
    <?php }; ?>
      </div>
    </div>
  </div>

  <div>
    </p><br><br></p>
  </div>




<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script>window.jQuery || document.write('<script src="/docs/4.4/assets/js/vendor/jquery.slim.min.js"><\/script>')</script><script src="/docs/4.4/dist/js/bootstrap.bundle.min.js" integrity="sha384-6khuMg9gaYr5AxOqhkVIODVIvm9ynTT5J4V1cfthmT+emCG6yVmEZsRHdxlotUnm" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<script>
    (function($){
          $('form').submit(function(event){

              var soumettre_form = true;
              var messages_erreurs = [];

              var titre = $('input[name=titre]', this).val();
              if(titre.length <20 ){
                soumettre_form = false;
                messages_erreurs.push('Titre doit comporter au moins 20 caracteres.');
              }
              var categorie = $('input[name=categorie]', this).val();
              if(typeof(categorie) == 'undefined'){
                soumettre_form = false;
                messages_erreurs.push("La catégorie n'a pas été selectionnée.");
              }

              var texte = $.trim($("#texte").val());
              if(texte.length < 60){
                soumettre_form = false;
                messages_erreurs.push('Decription doit comporter au moins 60 caracteres.');
              }
              var prix = $('input[name=prix]', this).val();
              if(prix.length ==0 ){
                soumettre_form = false;
                messages_erreurs.push('Le prix doit être renseigné.');
              }

              if(soumettre_form){
                return true;
              }
              else {
                event.preventDefault();
                alert(messages_erreurs.join("\n"));
                return false;
              }
          });

      })(jQuery);

  </script>

</body>
</html>
