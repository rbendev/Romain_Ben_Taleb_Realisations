<?php session_start() ?>

<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
    <!--   <link rel="stylesheet" href="css/main.css"> -->
    <!--    <script src="js/main.js"></script> -->
        <title>Projet NAOR : Nelly Alex Omar Romain</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>
    <body>

<?php
require_once(dirname(__FILE__) . '/classes/classeAnnonce.php');
require_once(dirname(__FILE__) . '/classes/classeUtilisateur.php');

$ma_classe_annonce = new classeAnnonce();
$ma_classe_utilisateur = new classeUtilisateur();


//Si l'utilisateur est authentifié
if(isset($_SESSION['user'])){
    //On affiche toutes les annonces dont l'utilisateur est prorpiétaire
    $liste_annonces = $ma_classe_annonce->getListeAnnoncesByUser($_SESSION['user']);
    //On récupère et on affiche les informations de l'utilisateur
    $utilisateur = $ma_classe_utilisateur->getUtilisateur($_SESSION['user']);
}

?>
<div class="sticky-top" style="border-bottom-style: solid; border-color: red;">
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <a href="index.php"><img src = "img/NAOR.png" class="img-fluid hoverable" alt="Responsive image" width="240" height="560"></a>
      <div class="container" role="main">
        <div class="row">

          <div class="col-3">
            <a href="toutesannonces.php"><button type="button" class="btnBienvenue sur le site d'annonces NAOR btn-info btn-lg btn-block" >Consulter les annonces</button></a>
          </div>

          <div class="col-3">
            <a href="formulaireannonce.php?from=poster"><button type="button" class="btn btn-danger btn-lg btn-block">Poster une annonce</button></a>
          </div>

          <div class="col-3">
            <a href="pageutilisateur.php"><button type="button" class="btn btn-info btn-lg btn-block">Consulter mon Compte</button></a>
          </div>

          <div class="col-3">
            <a href="index.php?todo=deconnexion"><button type="button" class="btn btn-warning btn-lg btn-block h-100">Déconnexion</button></a>
          </div>
      </div>
    </nav>
</div>

  <div>
    </p><br><br></p>
  </div>


<div class="container" role="main">

    <div class="row mt-5">
      <div class="col-2">
      </div>
      <div class="col-8">
        <div class="text-center">
          <h2>Vos informations personnelles</h2></br>
          <div class="card bg-danger h-100">
            <div class="card-body text-white ">
              <p>Nom : <?php echo $utilisateur['nom']; ?></p>
              <p>Prénom : <?php echo $utilisateur['prenom']; ?></p>
              <p>Email : <?php echo $utilisateur['email']; ?></p>
              <p>Téléphone : <?php echo $utilisateur['telephone']; ?></p>
              <p>Code Postal : <?php echo $utilisateur['code_postal']; ?></p>
              <p>Ville : <?php echo $utilisateur['ville']; ?></p>
              <p>Pays : <?php echo $utilisateur['pays']; ?></p>
            </div>
          </div>
        </div>
      </div>
      <div class="col-2">
      </div>
      <p></br></p>
    </div>

    <?php if($liste_annonces) { ?>
    <div class="container" role="main">
      <div class="row mt-5">
        <div class="col-12">
          <div class="text-center">
            <h2>Liste de vos annonces</h2>
          </div>
        </div>
      </div>
    <?php $compteur = 1; ?>
      <?php foreach($liste_annonces as $annonce) : ?>
      <?php if(($compteur + 1)%2 == 0) : ?>
        <div class="row mt-5">
      <?php endif;?>
      <div class="col-6 align-items-stretch">
        <?php if(($compteur-1)%4 == 0) : ?>
          <div class="card bg-primary mb-3 h-100">
        <?php endif;?>
        <?php if($compteur%2 == 0 && $compteur%4 != 0) : ?>
          <div class="card bg-warning h-100">
        <?php endif;?>
        <?php if((($compteur)==3 || ($compteur -3)%4 == 0) && ($compteur%2 != 0)) : ?>
          <div class="card bg-secondary h-100">
        <?php endif;?>
        <?php if(($compteur)%4 == 0) : ?>
          <div class="card bg-success h-100">
        <?php endif;?>
            <div class="card-body text-white ">
              <a href="pageconsultation.php?annonceid=<?php echo $annonce['annonceid']; ?>"><h5 class="card-header text-center text-white "><?php echo $annonce['titre']; ?></h5></a>
              <a href="pageconsultation.php?annonceid=<?php echo $annonce['annonceid']; ?>"><p class="card-text  text-center text-white "><img src = "<?php echo $annonce['photo']; ?>" class="img-fluid" alt="Responsive image" ></p></a>
              <p class="card-text  text-center"><?php echo $annonce['nom']; ?> <?php echo $annonce['prenom']; ?></p>
              <p class="card-text  text-center"><?php echo $annonce['prix']; ?>
              <?php if($annonce['prix']!=""){ ?>
              <?php echo "€";} ?>
                                                  </p>
              <p class="card-text  text-center"><?php echo $annonce['rubrique']; ?></p>
            </div>
          </div>
        </div>
      <?php if(($compteur)%2 == 0) : ?>
      </div>
      <?php endif;?>
    <?php $compteur++; ?>
    <?php endforeach; ?>
</div>
<?php } ?>
<?php if(!$liste_annonces) { ?>
<div class="container" role="main">
  <div class="row mt-5">
    <div class="col-12">
      <div class="text-center">
        <h2>Vous n'avez aucune annonce en cours</h2>
      </div>
    </div>
  </div>
</div>
<?php }; ?>
  </br></br></br>
</body>
</html>
