<?php session_start() ?>

<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
    <!--   <link rel="stylesheet" href="css/main.css"> -->
    <!--    <script src="js/main.js"></script> -->
        <title>Projet NAOR : Nelly Alex Omar Romain</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>
    <body>

<?php
require_once(dirname(__FILE__) . '/classes/classeAnnonce.php');
require_once(dirname(__FILE__) . '/classes/classeUtilisateur.php');

$ma_classe_annonce = new classeAnnonce();
$ma_classe_utilisateur = new classeUtilisateur();

//Si la page est rechargée grâce au formulaire de choix d'une Catégorie
//on récupère et on affiche toutes les annonces de cette catégorie
if(isset($_POST['categorie'])){
  $liste_annonces = $ma_classe_annonce->getListeAnnoncesByCategorie($_POST['categorie']);
}
else {
  //Si la page est chargée par une autre source (bannière, connexion au site)
  //on récupère et on affiche toutes les annonces de la base
  $liste_annonces = $ma_classe_annonce->getListeAnnonces();
}
?>
<div class="sticky-top" style="border-bottom-style: solid; border-color: red;">
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <a href="index.php"><img src = "img/NAOR.png" class="img-fluid hoverable" alt="Responsive image" width="240" height="560"></a>
      <div class="container" role="main">
        <div class="row">

          <div class="col-3">
            <a href="toutesannonces.php"><button type="button" class="btnBienvenue sur le site d'annonces NAOR btn-info btn-lg btn-block" >Consulter les annonces</button></a>
          </div>

          <div class="col-3">
            <a href="formulaireannonce.php?from=poster"><button type="button" class="btn btn-danger btn-lg btn-block">Poster une annonce</button></a>
          </div>

          <div class="col-3">
            <a href="pageutilisateur.php"><button type="button" class="btn btn-info btn-lg btn-block">Consulter mon Compte</button></a>
          </div>

          <div class="col-3">
            <a href="index.php?todo=deconnexion"><button type="button" class="btn btn-warning btn-lg btn-block h-100">Déconnexion</button></a>
          </div>
      </div>
    </nav>
</div>

  <div>
    </p><br><br></p>
  </div>

  <div class="row mt-5">
    <div class="col-12">
      <div class="text-center">
        <form method="post">
          <label class="radio-inline" for="categorie">
            <input type="radio" name="categorie" id="immobilier_up" value="Vente Immobilier">
            Vente Immobilier
            </label>

            <label class="radio-inline" for="categorie">
            <input type="radio" name="categorie" id="categorie" value="Offres Emploi">
            Offres Emploi
            </label>

            <label class=radio-inline for="categorie">
            <input type="radio" name="categorie" id="categorie" value="Informatique">
            Informatique
            </label>

            <label class="radio-inline" for="ameublement">
            <input type="radio" name="categorie" id="categorie" value="Ameublement">
              Ameublement
            </label>

            <label class="radio-inline" for="electromenager">
            <input type="radio" name="categorie" id="electromenager_up" value="Electroménager">
              Electroménager
            </label>
            </br>
            <button type="submit" class="btn btn-danger"><bold>Chercher !</bold></button>
          </div>
        </form>
      </div>
    </div>

<div class="container" role="main">
  <div class="row mt-5">
    <div class="col-12">
    <?php $compteur = 1; ?>
      <?php foreach($liste_annonces as $annonce) : ?>
      <?php if(($compteur + 1)%2 == 0) : ?>
        <div class="row mt-5">
      <?php endif;?>
      <div class="col-6 align-items-stretch">
        <?php if(($compteur-1)%4 == 0) : ?>
          <div class="card bg-primary mb-3 h-100">
        <?php endif;?>
        <?php if($compteur%2 == 0 && $compteur%4 != 0) : ?>
          <div class="card bg-warning h-100">
        <?php endif;?>
        <?php if((($compteur)==3 || ($compteur -3)%4 == 0) && ($compteur%2 != 0)) : ?>
          <div class="card bg-secondary h-100">
        <?php endif;?>
        <?php if(($compteur)%4 == 0) : ?>
          <div class="card bg-success h-100">
        <?php endif;?>
            <div class="card-body text-white ">
              <a href="pageconsultation.php?annonceid=<?php echo $annonce['annonceid']; ?>"><h5 class="card-header text-center text-white "><?php echo $annonce['titre']; ?></h5></a>
              <a href="pageconsultation.php?annonceid=<?php echo $annonce['annonceid']; ?>"><p class="card-text  text-center text-white "><img src = "<?php echo $annonce['photo']; ?>" class="img-fluid" alt="Responsive image" ></p></a>
              <p class="card-text  text-center"><?php echo $annonce['nom']; ?> <?php echo $annonce['prenom']; ?></p>
              <p class="card-text  text-center"><?php echo $annonce['prix']; ?>
              <?php if($annonce['prix']!=""){ ?>
              <?php echo "€";} ?>
                                                  </p>
              <p class="card-text  text-center"><?php echo $annonce['rubrique']; ?></p>
            </div>
          </div>
        </div>
      <?php if(($compteur)%2 == 0) : ?>
      </div>
      <?php endif;?>
    <?php $compteur++; ?>
    <?php endforeach; ?>
</div>
  </body>
</html>
