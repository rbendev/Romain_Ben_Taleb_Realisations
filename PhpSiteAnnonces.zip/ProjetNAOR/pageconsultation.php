<?php session_start() ?>

<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
    <!--   <link rel="stylesheet" href="css/main.css"> -->
    <!--    <script src="js/main.js"></script> -->
        <title>Projet NAOR : Nelly Alex Omar Romain</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    </head>
    <body>

<?php


require_once(dirname(__FILE__) . '/classes/classeAnnonce.php');
require_once(dirname(__FILE__) . '/classes/classeUtilisateur.php');

$ma_classe_annonce = new classeAnnonce();
$ma_classe_utilisateur = new classeUtilisateur();


//La consutlation d'unne annonce provient toujours de la consultation d'une liste d'liste_annonce
//Soit sur la page toutesannonces.php soit sur la page pageutilisateur.php
//Les pages sources indiquent toujours l'id de l'annonce source
//si elle est bien présente on crée une instance d'annonce et on va lire toutes les informations de l'annonce pour les afficher

if(count($_GET) > 0) {
	if(isset($_GET['annonceid'])) {
    //les informations de l'annonce contiennet les infomations de la table annonce
    //et les informations de son prorpiétaire grâce à une jointure de tables
    //toutes les informations sont retournées dans le memme tableau
    //on affiche les informations de la table annonce dans une card à gauche
    //on affiche les informations du prorpiétaire dans une card à DirectoryIterator
    //on affiche la localisation du propriétaire grâce à une iframe et une api google pourlaquelle on a généré une clé spécifique
  	$une_annonce = $ma_classe_annonce->getAnnonce($_GET['annonceid']);

    //Si la page a été chargée par un bouton de suppression d'annonces,
    //on supprime l'annonce
    if(isset($_GET['from']) && ($_GET['from']) == 'delete'){
      $ma_classe_annonce->deleteAnnonce($_GET['annonceid']);
    }
  }
}


?>
<div class="sticky-top" style="border-bottom-style: solid; border-color: red;">
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <a href="index.php"><img src = "img/NAOR.png" class="img-fluid hoverable" alt="Responsive image" width="240" height="560"></a>
      <div class="container" role="main">
        <div class="row">

          <div class="col-3">
            <a href="toutesannonces.php"><button type="button" class="btnBienvenue sur le site d'annonces NAOR btn-info btn-lg btn-block" >Consulter les annonces</button></a>
          </div>

          <div class="col-3">
            <a href="formulaireannonce.php?from=poster"><button type="button" class="btn btn-danger btn-lg btn-block">Poster une annonce</button></a>
          </div>

          <div class="col-3">
            <a href="pageutilisateur.php"><button type="button" class="btn btn-info btn-lg btn-block">Consulter mon Compte</button></a>
          </div>

          <div class="col-3">
            <a href="index.php?todo=deconnexion"><button type="button" class="btn btn-warning btn-lg btn-block h-100">Déconnexion</button></a>
          </div>
      </div>
    </div>
  </nav>
</div>


  <div>
    </p><br><br></p>
  </div>
      <div class="container" role="main">

      <div class="row mt-5">
        <div class="col-6">
            <div class="row">
              <div class="col-1">
              </div>
              <div class="col-10">

                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-header text-center">Annonce</h5>
                      <h5 class="card-header text-center"><?php echo $une_annonce['titre']; ?></h5>
                        <h5 class="card-text text-center"><?php echo $une_annonce['rubrique']; ?></h5>
                        <h5 class="card-text text-center"><?php echo $une_annonce['texte']; ?></h5>
                        <h5 class="card-text text-center"><?php echo $une_annonce['prix']; ?>
                          <?php if($une_annonce['prix']!=""){ ?>
                          <?php echo "€";} ?>
                        </h5>

                    </div>
                  </div>
                </div>
              <div class="col-1">
              </div>
            </div>
            <div class="row">
              <div class="col-1">
              </div>
              <div class="col-10">
                  <div class="card">
                    <div class="card-body">
                      <h5 class="card-header text-center"><img src = "<?php echo $une_annonce['photo']; ?>" class="img-fluid" alt="Responsive image" ></h5>
                    </div>
                  </div>
                </div>
              <div class="col-1">
              </div>
            </div>
          </div>


      <div class="col-6">

      <div class="row">
        <div class="col-1">
        </div>
            <div class="col-10">

                <div class="card">
                  <div class="card-body">
                        <p class="card-header text-center">Vendeur</p>
                        <p class="card-text text-center"><?php echo $une_annonce['nom']; ?> <?php echo $une_annonce['prenom']; ?></p>
                        <p class="card-text text-center"><?php echo $une_annonce['email']; ?></p>
                        <p class="card-text text-center"><?php echo $une_annonce['telephone']; ?></p>
                        <p class="card-text text-center"><?php echo $une_annonce['code_postal']; ?> <?php echo $une_annonce['ville']; ?> <?php echo $une_annonce['pays']; ?></p>
                        <p class="card-text  text-center"><?php echo $une_annonce['nom']; ?> <?php echo $une_annonce['prenom']; ?></p>

                      </div>
                    </div>
                    <?php if($_SESSION['user'] == $une_annonce['userid']) { ?>
                      <div class="card">
                        <div class="card-body">
                            <a href="formulaireannonce.php?from=annonce&annonceid=<?php echo $une_annonce['annonceid']; ?>"><button type="button" class="btn btn-info btn-lg btn-block" >Modifier l'annonce</button></a>
                        </div>
                      </div>
                      <div>
                        <div class="card">
                          <div class="card-body">
                              <a href="pageconsultation.php?from=delete&annonceid=<?php echo $une_annonce['annonceid']; ?>"><button type="button" class="btn btn-danger btn-lg btn-block">Supprimer l'annonce</button></a>
                          </div>
                        </div>
                      </div>
                    <?php }; ?>
                </div>
                  <div class="col-1">
                  </div>
              </div>
            </div>
          </div>

        <div class = "row mt-5 text-center">
          <div class="col-2 my-auto">
            <img src = "img/globe.jpg" class="img-fluid hoverable" alt="Responsive image" width="500" height="500">
          </div>
          <div class="col-8">
              <h2> Localisation du vendeur </h2>
              <div >
                <iframe src="https://www.google.com/maps/embed/v1/place?q=<?php echo $une_annonce['ville'] .'+'. $une_annonce['pays'] . '&key=AIzaSyC3WzfRTXG6i_bGWoui38tAZbD9Xs_TkkY&zoom=9'; ?>" style="height: 350px;border:0;" frameborder="0" width=100%></iframe>
              </div>
            </div>
            <div class="col-2 my-auto">
              <img src = "img/globe.jpg" class="img-fluid hoverable" alt="Responsive image" width="500" height="500">
            </div>
        </div>

    </div>

</body>
</html>
