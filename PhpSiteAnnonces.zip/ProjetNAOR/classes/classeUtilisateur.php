<?php

require_once('classeNettoyage.php');

class classeUtilisateur {

  private $base = 'annoncephp';
  private $user = 'stag';
  private $pwd = 'live';
  private $pdo;
  public $utilisateur=null;
  private $cleaner;



    //constructeur intialisant :
    // - la propriété pdo pour la connection à la bse de données
    // - la prorpiété cleaner pour créer un objet de netttoyage
  public function __construct(){

    $this->cleaner = new classeNettoyage();

    $dsn_string = 'mysql:dbname=' . $this->base . ';host:localhost';
    try {
    // Tentative de création de la de l'instance de la classe PDO
      $this->pdo = new PDO($dsn_string, $this->user, $this->pwd);
    }
    catch(DPOExcpetion $ex) {
      printf("Echec de la connection : %s\n", $ex->getMESSAGE());
    exit;
    }
  }

  //renvoie un tableau contenant toutes les informations de l'utilisateur identifié par son id
  public function getUtilisateur($userid){
    if ($this->utilisateur !== null){
      return $this->utilisateur;
    }
    else {
      $sql = "SELECT * FROM utilisateurs WHERE userid=$userid";
      $stmt = $this->pdo->query($sql);
      //LAnce notre requete
      if (!$stmt) {
        echo "Accès impossible";
      }
      else {
          $row = $stmt->fetch(PDO::FETCH_OBJ);
          if($row  && ($row->userid !== null)){
            $utilisateur = [
              'userid' => $row->userid,
              'email' => $row->email,
              'telephone' => $row->telephone,
              'nom' => $row->nom,
              'prenom' => $row->prenom,
              'code_postal' => $row->code_postal,
              'ville' => $row->ville,
              'pays' => $row->pays
            ];
        }
        $this->utilisateur = $utilisateur;
        return $utilisateur;
      }
    }
  }

  //Crée un utilisateur des la base grâce aux données passées en paramètre
  //les données proviennent d'un formulaire
    public function createUtilisateur($donnees_post){
      if(isset($donnees_post)) {
          /* INSERER DES DONNEES */
          $row = [
            $this->cleaner->clean($donnees_post['nom'], "phrase"),
            $this->cleaner->clean($donnees_post['prenom'], "phrase"),
            $this->cleaner->clean($donnees_post['code_postal'], "texte"),
            $this->cleaner->clean($donnees_post['ville'], "phrase"),
            $this->cleaner->clean($donnees_post['pays'], "phrase"),
            $this->cleaner->clean($donnees_post['email'], "texte"),
            $this->cleaner->clean($donnees_post['telephone'], "texte"),
            $this->cleaner->clean($donnees_post['login'], "texte"),
            $this->cleaner->clean($donnees_post['mdp'], "texte")
          ];
          $stmt = $this->pdo->prepare("INSERT INTO utilisateurs (nom, prenom, code_postal, ville, pays, email, telephone, username, pwd) VALUES (?,?,?,?,?,?,?,?,?)");
          try {
              $this->pdo->beginTransaction();
              $stmt->execute($row);
              $current_id = $this->pdo->lastInsertId();
              $this->pdo->commit();
              return $current_id;
          } catch (Exception $e){
              $this->pdo->rollback();
              throw $e;
            }
        }
      }


    //efface un utilisateur identifié par son id de la base de données
    public function deleteUtilisateur($id){
      $stmt = $this->pdo->prepare("DELETE FROM utilisateurs WHERE userid=?");
      $stmt->execute([$id]);
    }

    //met à jour les informations d'un utilisateur identifié par son id
    //cette fonction n'est pas implementée dans l'affichage et les interactions du site web
    public function updateUtilisateur($userid, $donnees) {
			// On supprime l'entrée dans la table informations_utilisateur
			$sql = "UPDATE utilisateurs
							SET
              email = :email,
							telephone = :telephone,
						  nom = :nom,
              prenom = :prenom,
							code_postal = :code_postal,
							ville = :ville,
              pays = :pays
							WHERE userid = :userid";
			$stmt = $this->pdo->prepare($sql);
      $stmt->bindParam(':email', $this->cleaner->clean($donnees['email'], "phrase"), PDO::PARAM_STR);
			$stmt->bindParam(':telephone', $this->cleaner->clean($donnees['telephone'], "phrase"), PDO::PARAM_STR);
			$stmt->bindParam(':nom', $this->cleaner->clean($donnees['nom'], "phrase"), PDO::PARAM_STR);
      $stmt->bindParam(':prenom', $this->cleaner->clean($donnees['prenom'], "phrase"), PDO::PARAM_STR);
			$stmt->bindParam(':code_postal', $this->cleaner->clean($donnees['code_postal'], "phrase"), PDO::PARAM_STR);
			$stmt->bindParam(':ville', $this->cleaner->clean($donnees['ville'], "phrase"), PDO::PARAM_STR);
      $stmt->bindParam(':pays', $this->cleaner->clean($donnees['pays'], "phrase"), PDO::PARAM_STR);
			$stmt->bindParam(':userid', $userid, PDO::PARAM_INT);
			$stmt->execute();
			// On supprime l'entrée dans la table utilisateurs
      //header('Location:/formation_php/exercices/Objets/MaClassePDO2/pageCorrection.php');
      exit;
		}
  }
?>
