<?php

class classPDO {


  private $base = 'annoncephp';
  private $user = 'stag';
  private $pwd = 'live';
  private $pdo;

  public function __construct(){
    $dsn_string = 'mysql:dbname=' . $this->base . ';host:localhost';
    try {
    // Tentative de création de la de l'instance de la classe PDO
      $this->pdo = new PDO($dsn_string, $this->user, $this->pwd);
      return $this->pdo;
    }
    catch(DPOExcpetion $ex) {
      printf("Echec de la connection : %s\n", $ex->getMESSAGE());
    exit;
    }
  }
}
?>
