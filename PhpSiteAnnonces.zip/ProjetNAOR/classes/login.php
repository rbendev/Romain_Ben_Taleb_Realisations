<?php

require('classeNettoyage.php');

class login {


  private $base = 'annoncephp';
  private $user = 'stag';
  private $pwd = 'live';
  private $pdo;
  public $userid=false;

  private $cleaner;

    //constructeur intialisant :
    // - la propriété pdo pour la connection à la bse de données
    // - la prorpiété cleaner pour créer un objet de netttoyage
  public function __construct(){

    $this->cleaner = new classeNettoyage();

    $dsn_string = 'mysql:dbname=' . $this->base . ';host:localhost';
    try {
    // Tentative de création de la de l'instance de la classe PDO
      $this->pdo = new PDO($dsn_string, $this->user, $this->pwd);
    }
    catch(DPOExcpetion $ex) {
      printf("Echec de la connection : %s\n", $ex->getMESSAGE());
    exit;
    }
  }


  //fonction permettant d'aller chercher dans la base de donnée
  //l'user id de l'utilisateur dont le mot de passe et le nom d'utilisateur sont passés en paramètres
  //renvoie false si l'utilisateur n'existe pas
  //renvoie l'id de l'uilisateur s'il existe
  public function connection($username, $pwd){

      $fill = [
        $this->cleaner->clean($username, "texte"),
        $this->cleaner->clean($pwd, "texte")
      ];
      $stmt = $this->pdo->prepare("SELECT u.userid FROM utilisateurs u WHERE (u.username = ?) AND (u.pwd = ?)");
      $stmt->execute($fill);
      //LAnce notre requete
      if ($stmt) {
          $row = $stmt->fetch();
          if($row){
            $this->userid = $row['userid'];
          }
      }
      else {
        $this->userid = false;
      }
      return $this->userid;
    }
}
?>
