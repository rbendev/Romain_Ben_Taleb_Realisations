<?php

require_once('classeNettoyage.php');

//Classe permettant les interactions basse de données - table annonces et les pages du site utilisant les annonces
class classeAnnonce {

  private $base = 'annoncephp';
  private $user = 'stag';
  private $pwd = 'live';
  private $pdo;
  public $annonce=false;
  public $liste_annonces=false;
  public $liste_annonces_user=false;
  private $cleaner;


  //constructeur intialisant :
  // - la propriété pdo pour la connection à la bse de données
  // - la prorpiété cleaner pour créer un objet de netttoyage
  public function __construct(){

    $this->cleaner = new classeNettoyage();

    $dsn_string = 'mysql:dbname=' . $this->base . ';host:localhost';
    try {
    // Tentative de création de la de l'instance de la classe PDO
      $this->pdo = new PDO($dsn_string, $this->user, $this->pwd);
    }
    catch(DPOExcpetion $ex) {
      printf("Echec de la connection : %s\n", $ex->getMESSAGE());
    exit;
    }
  }

  //revoie dans un tableau toutes les données relatives à une annonce spécifiée par son id
  public function getAnnonce($annonceid){
    if ($this->annonce !== false){
      return $this->annonce;
    }
    else {
      $sql = "SELECT a.*, u.* FROM annonces a
            LEFT JOIN utilisateurs u on u.userid = a.userid WHERE annonceid=$annonceid";
      $stmt = $this->pdo->query($sql);
      //LAnce notre requete
      if (!$stmt) {
        echo "Accès impossible";
      }
      else {
          $row = $stmt->fetch(PDO::FETCH_OBJ);
          //echo '<pre>'. print_r($row, true) . '</pre>';
          if($row  && ($row->annonceid !== null)){
            $annonce = [
              'annonceid' => $row->annonceid,
              'userid' => $row->userid,
              'titre' => $row->titre,
              'texte' => $row->text,
              'prix' => $row->prix,
              'rubrique' => $row->rubrique,
              'photo' => $row->photo,
              'prenom' => $row->prenom,
              'nom' => $row->nom,
              'email' => $row->email,
              'telephone' => $row->telephone,
              'code_postal' => $row->code_postal,
              'ville' => $row->ville,
              'pays' => $row->pays
              //'date' => $row->pays
            ];
          }
        $this->annonce = $annonce;
        return $annonce;
      }
    }
  }

  //renvoir la liste de toutes les annonces de toutes leurs informations
  public function getListeAnnonces(){
    if ($this->liste_annonces !== false){
      return $this->liste_annonces;
    }
    else {
      $sql = "SELECT a.*, u.nom, u.prenom FROM annonces a
            LEFT JOIN utilisateurs u on u.userid = a.userid";
      $stmt = $this->pdo->query($sql);
      //LAnce notre requete
      if ($stmt) {
          while($row = $stmt->fetch()){
          //echo '<pre>'. print_r($row, true) . '</pre>';
          if($row  && ($row['annonceid'] !== null)){
            $liste_annonces[] = [
              'annonceid' => $row['annonceid'],
              'userid' => $row['userid'],
              'titre' => $row['titre'],
              'texte' => $row['text'],
              'prix' => $row['prix'],
              'rubrique' => $row['rubrique'],
              'prenom' => $row['prenom'],
              'nom' => $row['nom'],
              'photo' => $row['photo']
              //'date' => $row->pays
            ];
        }
      }
        $this->liste_annonces = $liste_annonces;
        return $liste_annonces;
      }
    }
  }

  //renvoie la liste de toutes les annonces et leurs informations
  //seulement les annonces de l'utilisateur dont l'id est spécifiée
  public function getListeAnnoncesByUser($userid){
    if ($this->liste_annonces_user !== false){
      return $this->liste_annonces_user;
    }
    else {
      $liste_annonces_u = false;
      $sql = "SELECT a.*, u.nom, u.prenom FROM annonces a
            LEFT JOIN utilisateurs u on u.userid = a.userid
            WHERE a.userid=$userid";
      $stmt = $this->pdo->query($sql);
      //LAnce notre requete
      if ($stmt) {
          while($row = $stmt->fetch()){
          //echo '<pre>'. print_r($row, true) . '</pre>';
          if($row  && ($row['annonceid'] !== null)){
            $liste_annonces_u[] = [
              'annonceid' => $row['annonceid'],
              'userid' => $row['userid'],
              'titre' => $row['titre'],
              'texte' => $row['text'],
              'prix' => $row['prix'],
              'rubrique' => $row['rubrique'],
              'prenom' => $row['prenom'],
              'nom' => $row['nom'],
              'photo' => $row['photo']
              //'date' => $row->pays
            ];
          }
        }
      }
      $this->liste_annonces_user = $liste_annonces_u;
      return $liste_annonces_u;
    }
  }

  //renvoie une liste d'annonces et toutes leurs informations dans un tableau
  //seulement la lite des annonces dont la rubrique est spéficiée
  public function getListeAnnoncesByCategorie($categorie){
      $liste_annonces_u = false;
      $sql = "SELECT a.*, u.nom, u.prenom FROM annonces a
            LEFT JOIN utilisateurs u on u.userid = a.userid
            WHERE a.rubrique='$categorie'";
      $stmt = $this->pdo->query($sql);
      //LAnce notre requete
      if ($stmt) {
          while($row = $stmt->fetch()){
          if($row  && ($row['annonceid'] !== null)){
            $liste_annonces_u[] = [
              'annonceid' => $row['annonceid'],
              'userid' => $row['userid'],
              'titre' => $row['titre'],
              'texte' => $row['text'],
              'prix' => $row['prix'],
              'rubrique' => $row['rubrique'],
              'prenom' => $row['prenom'],
              'nom' => $row['nom'],
              'photo' => $row['photo']
              //'date' => $row->pays
            ];
          }
        }
      }
      $this->liste_annonces_user = $liste_annonces_u;
      return $liste_annonces_u;
    }


    //créee une annonce dans la table de la base
    //prend en paramètre les informations nécessaires
    //ces données proviennent d'un formalaire
    public function createAnnonce($donnees_post, $user){
      if(isset($donnees_post)) {
          /* INSERER DES DONNEES */
          if($donnees_post['categorie'] == "Vente Immobilier" ){
            $photo = "img/villamer.jpeg";
          }
          else if($donnees_post['categorie'] == "Offres Emploi"){
            $photo = "img/developpeur.jpg";
          }
          else if($donnees_post['categorie'] == "Informatique"){
            $photo = "img/ordinateur.jpg";
          }
          else if($donnees_post['categorie'] == "Ameublement"){
            $photo = "img/buffet.jpeg";
          }
          else if($donnees_post['categorie'] ==  "Electroménager"){
            $photo = "img/thermomix.jpg" ;
          }
          else {
            $photo = "";
          }
          $row = [
            $user,
            $this->cleaner->clean($donnees_post['titre'], "phrase"),
            $this->cleaner->clean($donnees_post['texte'], "phrase"),
            $this->cleaner->clean($donnees_post['prix'], "texte"),
            $this->cleaner->clean($donnees_post['categorie'], "texte"),
            $photo
            //$donnees_post['date'],
          ];
          echo '<pre> userid' . print_r($row, true) . '</pre>';
          $stmt = $this->pdo->prepare("INSERT INTO annonces (userid, titre, text, prix, rubrique, photo) VALUES (?,?,?,?,?,?)");
          try {
              $this->pdo->beginTransaction();
              $stmt->execute($row);
              $this->pdo->commit();
              echo '<pre> Execute </pre>';

          } catch (Exception $e){
              $this->pdo->rollback();
              throw $e;
          }
      }
      header('Location:/ProjetNAOR/toutesannonces.php');
    }

    //supprime une annonce connue par son id
    public function deleteAnnonce($id){
      $stmt = $this->pdo->prepare("DELETE FROM annonces WHERE annonceid=?");
      $stmt->execute([$id]);
      header('Location:/ProjetNAOR/pageutilisateur.php');
    }

    //met à jour une annonce grâce aux informations en paramètres
    //l'annonce est identifiée par son id
    //l'utilsateur est soécifié par son id qui provient de la globale $_SESSION
    //les données à mettre à jour proviennent d'un formulaire
    public function updateAnnonce($annonceid, $donnees, $user) {
			$sql = "UPDATE annonces
							SET
              userid = :userid,
							titre = :titre,
						  text = :text,
              prix = :prix,
							rubrique = :rubrique
							WHERE annonceid = :annonceid";
			$stmt = $this->pdo->prepare($sql);
      $stmt->bindParam(':userid', $user, PDO::PARAM_STR);
			$stmt->bindParam(':titre', $this->cleaner->clean($donnees['titre'], "phrase"), PDO::PARAM_STR);
			$stmt->bindParam(':text', $this->cleaner->clean($donnees['texte'], "phrase"), PDO::PARAM_STR);
      $stmt->bindParam(':prix', $this->cleaner->clean($donnees['prix'], "texte"), PDO::PARAM_STR);
			$stmt->bindParam(':rubrique', $this->cleaner->clean($donnees['categorie'], "texte"), PDO::PARAM_STR);
			$stmt->bindParam(':annonceid', $annonceid, PDO::PARAM_INT);
			$stmt->execute();
      header('Location:/ProjetNAOR/toutesannonces.php');
      exit;
		}
}
?>
