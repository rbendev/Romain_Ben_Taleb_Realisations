<?php

class classeNettoyage{

  function nettoiePhrase($phrase){
    $phrase_propre = strip_tags($phrase);
    $phrase_propre = trim($phrase_propre);
    $phrase_propre = ucfirst($phrase_propre);
    return $phrase_propre;
    }

  function nettoieStandard($texte){
    $phrase_propre = strip_tags($texte);
    $phrase_propre = trim($phrase_propre);
    return $phrase_propre;
  }

  function nettoieEmail($email){
    $email_propre = "";
    $email_propre = $this->nettoieStandard($email);
    if (!filter_var($email_propre, FILTER_VALIDATE_EMAIL)){
      $email_propre = "";
      }
        return $email_propre;
  }

  //la fonction est la seule à etre utilisée à l'extérieur de la classes
  //elle utilise les 3 fonctions précédentes selon le paramètre $type
  //$phrase est uilisée pour nettoyer une chaine de caractères avec en plus une mise en majuscule du 1er caractèreq
  //$texte utilisé la fonction de base qui trim et strip strip_tags
  //$email est spécifique à la vérifiation des email
  function clean($input, $type){
    if($type == "phrase"){
      return $this->nettoiePhrase($input);
    }
    if($type == "texte"){
      return $this->nettoieStandard($input);
    }
    if($type == "mail"){
      return $this->nettoieEmail($input);
    }
  }
}
?>
