-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 29, 2020 at 01:55 PM
-- Server version: 10.3.22-MariaDB-0+deb10u1
-- PHP Version: 7.3.18-1+0~20200515.59+debian10~1.gbp12fa4f

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `annoncephp`
--

-- --------------------------------------------------------

--
-- Table structure for table `annonces`
--

CREATE TABLE `annonces` (
  `annonceid` int(11) NOT NULL,
  `userid` varchar(11) NOT NULL,
  `titre` text NOT NULL,
  `text` text NOT NULL,
  `prix` varchar(32) DEFAULT NULL,
  `rubrique` varchar(64) NOT NULL,
  `photo` text NOT NULL DEFAULT current_timestamp(),
  `date` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `annonces`
--

INSERT INTO `annonces` (`annonceid`, `userid`, `titre`, `text`, `prix`, `rubrique`, `photo`, `date`) VALUES
(1, '2', 'Vente magnifique villa !', 'Maison de 300 mètres carrrés avec vue sur mer.\r\n3 chambres 2 salles de bains 1 cuisine ouverte 1 garage 1 piscine', '550000', 'Vente Immobilier', 'img/villamer.jpeg', '2020-06-25 09:45:49'),
(3, '3', 'PC Portable Neuf !! Super autonomie de batterie', 'Ecran 15 pouces\r\nDisque Dur SSD 512Go\r\nCarte Graphique 2Go\r\nRAM 8 Go !!', '800', 'Informatique', 'img/ordinateur.jpg', '2020-06-23 21:08:03'),
(4, '4', 'Magnifique Buffet Stype Cheependale en bois sculpté\r\n', 'Comporte 3 étagères\r\n2 portes vitrées coulissantes\r\nLongueur 170 cm', '80', 'Ameublement', 'img/buffet.jpeg', '2020-06-23 21:08:21'),
(9, '2', 'Offre d\'emploi Développeur Front End', 'Job dans une boite sympa ', '3000', 'Offres Emploi', 'img/developpeur.jpg', '2020-06-25 10:35:38'),
(10, '2', 'Maison en bord de plage !', ' Maison 150metres carrés agréable en bord de plage !\r\nPas de piscine mais la plage à 50 mètres', '310000', 'Vente Immobilier', 'img/villamer.jpeg', '2020-06-25 10:39:58'),
(11, '2', 'Disque Dur Externe 2TO', ' Disque SATA 2To Bon état', '40', 'Informatique', 'img/ordinateur.jpg', '2020-06-25 10:48:02'),
(12, '2', 'Buffet Ancien', ' Buffet Ancien en bois massif', '60', 'Ameublement', 'img/buffet.jpeg', '2020-06-25 11:01:01'),
(13, '4', 'Superbe Thermomix TM2020', ' Thermomix\r\nParfait pour la cuisine\r\n200 recettes préenregistrées\r\nAppareil connecté', '820', 'Electroménager', 'img/thermomix.jpg', '2020-06-25 16:19:06'),
(14, '4', 'Offre 3 emplois Développeur Web', ' 3 postes au sein de 3 équipes de développement\r\nSalaire attractif', '2500', 'Offres Emploi', 'img/developpeur.jpg', '2020-06-25 16:26:16'),
(15, '2', 'Suberbe Maison avec Piscine', 'Superbe maison comportant 4 chambres 2 salles de bain 1 grand salon de 50metres carrés ', '450000', 'Vente Immobilier', 'img/villamer.jpeg', '2020-06-26 07:33:50'),
(16, '3', 'Vente Machine à popcorn :)', ' Superbe machine à popcorn\r\nChargement de 4kg\r\nConditionnement par sachet de 200g', '500', 'Electroménager', 'img/thermomix.jpg', '2020-06-26 08:27:10'),
(17, '3', 'Machine à glaçons !!', ' Machine à glaçons\r\nVous sert 4 glaçons à la fois dans vos verres, caraffes et autres contenants !\r\nParfait pour les journées de canicule', '60', 'Electroménager', 'img/thermomix.jpg', '2020-06-26 08:47:47'),
(18, '3', 'Etagère multifonction 3 étages', 'Etagere en bois 3m x 2.50m\r\nCouleur noire\r\nContient 9 cases sur trois étages\r\nParfait pour vos livres bibelots et autres accessoires ', '120', 'Ameublement', 'img/buffet.jpeg', '2020-06-26 08:50:34'),
(20, '2', 'Nouvelle annonce pour les tests de recette', 'Cette annonce est postée pour vérifier la fonctionnalité de création d\'annonce', '1', 'Informatique', 'img/ordinateur.jpg', '2020-06-29 08:03:51'),
(21, '9', 'Annonce de test pour la classe nettoyage', 'Annonce de test pour la classe nettoyage !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!', '1', 'Vente Immobilier', 'img/villamer.jpeg', '2020-06-29 09:23:23');

-- --------------------------------------------------------

--
-- Table structure for table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `userid` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `pwd` varchar(40) NOT NULL,
  `email` varchar(64) NOT NULL,
  `telephone` varchar(32) NOT NULL,
  `nom` varchar(32) NOT NULL,
  `prenom` varchar(32) NOT NULL,
  `code_postal` varchar(32) NOT NULL,
  `ville` varchar(32) NOT NULL,
  `pays` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `utilisateurs`
--

INSERT INTO `utilisateurs` (`userid`, `username`, `pwd`, `email`, `telephone`, `nom`, `prenom`, `code_postal`, `ville`, `pays`) VALUES
(1, 'a.gri', 'a.gri', 'grimal.alexandre.82@gmail.com', '0634643524', 'GRIMAL', 'Alexandre', '22000', 'Saint-Brieuc', 'France'),
(2, 'r.ben', 'r.ben', 'r.ben-taleb@tbs-education.org', '0645763423', 'BEN-TALEB', 'Romain', '24000', 'Périgueux', 'France'),
(3, 'o.mes', 'o.mes', 'omessadi@gmail.com', '0683452345', 'MESSADI', 'Omar', '73000', 'Chambéry', 'France'),
(4, 'p.nel', 'p.nel', 'palassynelly@hotmail.fr', '0756453423', 'PALASSY', 'Nelly', '89000', 'Auxerre', 'France'),
(5, 'g.dup', 'g.dup', 'g.dup@gmail.com', '0101010101', 'Gérard', 'Dupont', '81000', 'Albi', 'France'),
(8, 'albertjacka', 'Albertjacka1', 'a.j@gmail.com', '1111111111', 'Jacka', 'Albert', '31000', 'Toulouse', 'France'),
(9, 'm.durand', 'Huitlettres1', 'm.durand@gmail.com', '0101010101', 'Durand', 'Marcel', '31000', 'Toulouse', 'France'),
(10, 'jeanpaul', 'JeanPaul1', 'jeanpaul@gmail.com', '0101010101', 'Jean', 'Paul', '81000', 'Albi', 'France');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `annonces`
--
ALTER TABLE `annonces`
  ADD PRIMARY KEY (`annonceid`);

--
-- Indexes for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `annonces`
--
ALTER TABLE `annonces`
  MODIFY `annonceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
